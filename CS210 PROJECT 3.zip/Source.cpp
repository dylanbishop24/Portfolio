#include <Python.h>
#include <iostream>
#include <Windows.h>
#include <cmath>
#include <string>

using namespace std;

/*
Description:
        To call this function, simply pass the function name in Python that you wish to call.
Example:
        callProcedure("printsomething");
Output:
        Python will print on the screen: Hello from python!
Return:
        None
*/
void CallProcedure(string pName)
{
    char* procname = new char[pName.length() + 1];
    std::strcpy(procname, pName.c_str());

    Py_Initialize();
    PyObject* my_module = PyImport_ImportModule("CS210_Starter_PY_Code (3)");
    PyErr_Print();
    PyObject* my_function = PyObject_GetAttrString(my_module, procname);
    PyObject* my_result = PyObject_CallObject(my_function, NULL);
    Py_Finalize();

    delete[] procname;
}

/*
Description:
        To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
        int x = callIntFunc("PrintMe","Test");
Output:
        Python will print on the screen:
                You sent me: Test
Return:
        100 is returned to the C++
*/
int callIntFunc(string proc, string param)
{
    char* procname = new char[proc.length() + 1];
    std::strcpy(procname, proc.c_str());

    char* paramval = new char[param.length() + 1];
    std::strcpy(paramval, param.c_str());


    PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
    // Initialize the Python Interpreter
    Py_Initialize();
    // Build the name object
    pName = PyUnicode_FromString((char*)"CS210_Starter_PY_Code (3)");
    // Load the module object
    pModule = PyImport_Import(pName);
    // pDict is a borrowed reference 
    pDict = PyModule_GetDict(pModule);
    // pFunc is also a borrowed reference 
    pFunc = PyDict_GetItemString(pDict, procname);
    if (PyCallable_Check(pFunc))
    {
        pValue = Py_BuildValue("(z)", paramval);
        PyErr_Print();
        presult = PyObject_CallObject(pFunc, pValue);
        PyErr_Print();
    }
    else
    {
        PyErr_Print();
    }
    //printf("Result is %d\n", _PyLong_AsInt(presult));
    Py_DECREF(pValue);
    // Clean up
    Py_DECREF(pModule);
    Py_DECREF(pName);
    // Finish the Python Interpreter
    Py_Finalize();

    // clean 
    delete[] procname;
    delete[] paramval;


    return _PyLong_AsInt(presult);
}

/*
Description:
        To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
        int x = callIntFunc("doublevalue",5);
Return:
        25 is returned to the C++
*/
int callIntFunc(string proc, int param)
{
    char* procname = new char[proc.length() + 1];
    std::strcpy(procname, proc.c_str());

    PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
    // Initialize the Python Interpreter
    Py_Initialize();
    // Build the name object
    pName = PyUnicode_FromString((char*)"CS_210_Starter_PY_Code (3)");
    // Load the module object
    pModule = PyImport_Import(pName);
    // pDict is a borrowed reference 
    pDict = PyModule_GetDict(pModule);
    // pFunc is also a borrowed reference 
    pFunc = PyDict_GetItemString(pDict, procname);
    if (PyCallable_Check(pFunc))
    {
        pValue = Py_BuildValue("(i)", param);
        PyErr_Print();
        presult = PyObject_CallObject(pFunc, pValue);
        PyErr_Print();
    }
    else
    {
        PyErr_Print();
    }
    //printf("Result is %d\n", _PyLong_AsInt(presult));
    Py_DECREF(pValue);
    // Clean up
    Py_DECREF(pModule);
    Py_DECREF(pName);
    // Finish the Python Interpreter
    Py_Finalize();

    // clean 
    delete[] procname;

    return _PyLong_AsInt(presult);
}


void main()
{

    int user_input = -1; //This is used to store the users input of each menu selection
    while (user_input != 4)      // Continue to display the menu until the user selects 4, then exit the menu.
    {
        try  
        {

            cout << "======================================================== \nMENU\n"; //Display the menu to the user
            cout << "1. What is the number of times each item appears?\n";
            cout << "2. Determine the amount of times each item shows up. \n";
            cout << "3. Display a text-file based histogram of the data. \n";
            cout << "========================================================\n";
            cout << "What would you like to do? : \n";

            cin >> user_input; //obtain the user's input for the choice of the item

            if (user_input == 1) //If the user chooses 1 for the frequency  
            {
                cout << "Frequency of items is : \n";
                cout << callIntFunc("get_frequency_of_each_item", "") << "\n";  //Get the amount of times the item appears 
            }
            else if (user_input == 2) //if the user chooses 2 for the frequency of the item
            {
                cout << "Enter the item's name, to get the frequency that you want : \n"; //Get the amount the user wants for the item chosen 
                string item;
                cin >> item;
                cout << callIntFunc("get_frequency_of_single_item", item) << "\n";
            }
            else if (user_input == 3)   // If the user chooses 3 for the frequency of the item
            {
                cout << "The histpgram format of the data is: \n";
                cout << callIntFunc("show_histogram", "") << "\n";  //Show the histogram of the data for the items chosen.
            }
            else
            {
                break;
            }
        }
        catch (...)
        {
            cout << "Error, please check your choice and try again." << "\n";
        }
    }
    return;
}