
import re

import string

import os.path

from os import path


def CountAll():

#Opening CS210_Project_Three_Input_File.txt

text = open("CS210_Project_Three_Input_File.txt", "r")

#Create a dictionary for words that are discovered

dictionary = dict()

#Inspect each line of the input text data.

for line in text:


line = line.strip()

#Change the words to all lowercase letters

item = line.lower()

  

#Find out if the word is already displayed in the dictionary

if item in dictionary:

#Count the amount of times the word appears in the dictionary

dictionary[item] = dictionary[item] + 1

else:

#If the word does not appear in the dictionary then add a value of one to it.

dictionary[item] = 1

#Display all of the contents from the dictionary

for key in list (dictionary.keys()):

print(key.capitalize(), ":", dictionary[key])

#Close the file that was previously opened in program.

text.close()



def CountInstances(searchTerm):

#Change the user input to lowercase letters

searchTerm = searchTerm.lower()


text = open("CS210_Project_Three_Input_File.txt", "r")

#Creating a variable to keep track of how many times an item appears

itemCount = 0

for line in text:

line = line.strip()

item = line.lower()

#Check if the user input matches an item in the dictionary

if item == searchTerm:

#Count how many times an item appears

itemCount += 1

return itemCount

#Close the CS210_Project_Three_Input_File.txt

text.close()

def CollectData():

#Open CS210_Project_Three_Input_File.txt

text = open("CS210_Project_Three_Input_File.txt", "r")

#Creating the frequency.dat file

frequency = open("frequency.dat", "w")

dictionary = dict()

for line in text:

line = line.strip()

item = line.lower()

#Check the dictionary to see if the item already appears.

if item in dictionary:

#Find out how many times the item appears in the dictionary that was created.

dictionary[item] = dictionary[item] + 1

else:

#If the item does not appear in the dictionary then add the value of 1 to the item.

dictionary[item] = 1

#Create each key and pair value and add it to frequency.dat to write it

for key in list (dictionary.keys()):

#Formatting the key and value pair as strings

frequency.write(str(key.capitalize()) + " " + str(dictionary[key]) + "\n")

#Close all of the files that were opened in the program

text.close()

frequency.close()
